from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.models.atauth.tokenizer import view_reshape, view_inverse


class MultiHeadAttention(nn.Module):
    def __init__(self, view: str, channel_in: int, num_heads: int, head_dim: int, t1: int, t2: int, d: int, t: int):
        super().__init__()
        self.view = view
        self.channel_in = channel_in
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.model_dim = num_heads * head_dim
        self.t1 = t1
        self.t2 = t2
        self.d = d
        self.t = t
        self.qkv = nn.Linear(channel_in, 3 * self.model_dim, bias=False)
        self.out_proj = nn.Linear(self.model_dim, channel_in, bias=False)
        self.scale = 1.0 / math.sqrt(head_dim)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        x = view_reshape(z, self.view, self.t1, self.t2)
        residual = x
        b, n, c = x.shape
        qkv = self.qkv(x)
        qkv = qkv.reshape(b, n, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale
        attn = torch.softmax(scores, dim=-1)
        out = torch.matmul(attn, v)
        out = out.transpose(1, 2).reshape(b, n, self.model_dim)
        out = self.out_proj(out)
        x = residual + out
        return view_inverse(x, self.view, self.d, self.t, self.t1, self.t2)
