from __future__ import annotations

import torch
import torch.nn as nn


class FactorizationMachineHead(nn.Module):
    def __init__(self, in_dim: int, k: int, num_classes: int = 2):
        super().__init__()
        self.in_dim = in_dim
        self.k = k
        self.num_classes = num_classes
        self.bias = nn.Parameter(torch.zeros(num_classes))
        self.linear = nn.Parameter(torch.zeros(num_classes, in_dim))
        self.factors = nn.Parameter(torch.randn(num_classes, in_dim, k) * 0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b = x.shape[0]
        linear_term = torch.einsum("bd,cd->bc", x, self.linear)
        x_unsq = x.unsqueeze(1).unsqueeze(-1)
        v = self.factors.unsqueeze(0)
        sum_sq = (x_unsq * v).sum(dim=2) ** 2
        sq_sum = ((x_unsq ** 2) * (v ** 2)).sum(dim=2)
        pairwise = 0.5 * (sum_sq - sq_sum).sum(dim=-1)
        return self.bias.unsqueeze(0).expand(b, -1) + linear_term + pairwise
