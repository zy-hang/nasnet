from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.models.atauth.search_space import CNNChoice


def _funnel_widths(in_channels: int, num_stages: int) -> list[int]:
    if num_stages <= 0:
        return [in_channels]
    if in_channels <= 1:
        return [in_channels] * (num_stages + 1)
    widths = [in_channels]
    step = max(1, (in_channels - 1) // num_stages)
    for stage in range(num_stages):
        if stage == num_stages - 1:
            widths.append(1)
        else:
            widths.append(max(1, widths[-1] - step))
    return widths


def _conv_out_length(length_in: int, kernel: int, stride: int, padding: int) -> int:
    return (length_in + 2 * padding - kernel) // stride + 1


class PersonalizedCNNExtractor(nn.Module):
    def __init__(self, cnn: CNNChoice, in_channels: int, time_length: int, num_stages: int = 4):
        super().__init__()
        assert len(cnn.kernel_sizes) == num_stages
        assert len(cnn.strides) == num_stages
        widths = _funnel_widths(in_channels, num_stages)
        self.convs = nn.ModuleList()
        self.norms = nn.ModuleList()
        cur_len = time_length
        for stage in range(num_stages):
            ks = cnn.kernel_sizes[stage]
            stride = cnn.strides[stage]
            pad = (ks - 1) // 2
            self.convs.append(
                nn.Conv1d(widths[stage], widths[stage + 1], kernel_size=ks, stride=stride, padding=pad)
            )
            self.norms.append(nn.BatchNorm1d(widths[stage + 1]))
            cur_len = _conv_out_length(cur_len, ks, stride, pad)
        self.out_channels = widths[-1]
        self.out_time = cur_len
        self.out_dim = self.out_channels * self.out_time

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        x = z
        for conv, norm in zip(self.convs, self.norms):
            x = F.relu(norm(conv(x)))
        return x.flatten(start_dim=1)
