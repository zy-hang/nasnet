from __future__ import annotations

import torch
import torch.nn as nn

from src.models.atauth.adaptive_layer import build_slot_module
from src.models.atauth.atauth_model import ATAuthModel
from src.models.atauth.search_space import Architecture, architecture_signature


_FLOPS_CACHE: dict[str, float] = {}
_LATENCY_CACHE: dict[str, float] = {}


def _count_module_flops(module: nn.Module, input_shape: tuple[int, ...]) -> float:
    flops = 0.0
    handles = []

    def hook_factory(name: str):
        def hook(mod: nn.Module, inputs, outputs):
            nonlocal flops
            if isinstance(mod, nn.Linear):
                if isinstance(outputs, torch.Tensor):
                    out = outputs
                else:
                    out = outputs[0]
                flops += float(out.numel() * mod.in_features)
            elif isinstance(mod, nn.Conv1d):
                if isinstance(outputs, torch.Tensor):
                    out = outputs
                else:
                    out = outputs[0]
                kernel_ops = mod.kernel_size[0] * (mod.in_channels // mod.groups)
                flops += float(out.numel() * kernel_ops)
        return hook

    for name, sub in module.named_modules():
        if isinstance(sub, (nn.Linear, nn.Conv1d)):
            handles.append(sub.register_forward_hook(hook_factory(name)))

    module.eval()
    with torch.no_grad():
        x = torch.zeros(*input_shape)
        module(x)

    for h in handles:
        h.remove()
    return flops


def estimate_flops(arch: Architecture, d: int, t: int, t1: int, t2: int) -> float:
    sig = f"{architecture_signature(arch)}::{d}::{t}::{t1}::{t2}"
    if sig in _FLOPS_CACHE:
        return _FLOPS_CACHE[sig]
    model = ATAuthModel(arch=arch, d=d, t=t, t1=t1, t2=t2)
    val = _count_module_flops(model, (1, t, d))
    _FLOPS_CACHE[sig] = val
    return val


def estimate_latency_proxy(arch: Architecture, d: int, t: int, t1: int, t2: int) -> float:
    sig = f"{architecture_signature(arch)}::{d}::{t}::{t1}::{t2}"
    if sig in _LATENCY_CACHE:
        return _LATENCY_CACHE[sig]
    flops = estimate_flops(arch, d, t, t1, t2)
    moe_penalty = 0.0
    for layer in arch.layers:
        for slot in (layer.slot_a, layer.slot_b):
            if slot.operator == "dc_smoe":
                moe_penalty += 0.05 * slot.num_experts
            else:
                moe_penalty += 0.02 * slot.num_heads * slot.head_dim / 32.0
    val = (flops / 1e6) + moe_penalty
    _LATENCY_CACHE[sig] = val
    return val


def clear_cache() -> None:
    _FLOPS_CACHE.clear()
    _LATENCY_CACHE.clear()
