from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.models.atauth.tokenizer import view_reshape, view_inverse


class _SharedFFN(nn.Module):
    def __init__(self, dim: int, hidden_dim: int):
        super().__init__()
        self.fc2 = nn.Linear(dim, hidden_dim, bias=False)
        self.fc3 = nn.Linear(dim, hidden_dim, bias=False)
        self.fc1 = nn.Linear(hidden_dim, dim, bias=False)

    def forward(self, u: torch.Tensor) -> torch.Tensor:
        gate = F.silu(self.fc2(u))
        return self.fc1(gate * self.fc3(u))


class _DepthwiseConvExpert(nn.Module):
    def __init__(self, dim: int, kernel_size: int, stride: int):
        super().__init__()
        pad = (kernel_size - 1) // 2
        self.stride = stride
        self.dc1 = nn.Conv1d(dim, dim, kernel_size=kernel_size, stride=stride, padding=pad, groups=dim, bias=False)
        self.dc2 = nn.Conv1d(dim, dim, kernel_size=kernel_size, stride=stride, padding=pad, groups=dim, bias=False)
        self.fc = nn.Linear(dim, dim, bias=False)

    def forward(self, u: torch.Tensor) -> torch.Tensor:
        n_in = u.shape[1]
        x = u.transpose(1, 2)
        a = F.silu(self.dc1(x))
        b = self.dc2(x)
        n_a = a.shape[-1]
        n_b = b.shape[-1]
        n_min = min(n_a, n_b)
        y = a[..., :n_min] * b[..., :n_min]
        if self.stride != 1:
            y = F.interpolate(y, size=n_in, mode="linear", align_corners=False)
        elif y.shape[-1] != n_in:
            if y.shape[-1] > n_in:
                y = y[..., :n_in]
            else:
                y = F.pad(y, (0, n_in - y.shape[-1]))
        y = y.transpose(1, 2)
        return self.fc(y)


class DCsMoE(nn.Module):
    def __init__(
        self,
        view: str,
        channel_in: int,
        num_routed_experts: int,
        topk: int,
        t1: int,
        t2: int,
        d: int,
        t: int,
        num_shared_experts: int = 1,
        shared_hidden_ratio: float = 0.5,
        kernel_size: int = 3,
        stride: int = 2,
    ):
        super().__init__()
        self.view = view
        self.channel_in = channel_in
        self.num_routed_experts = num_routed_experts
        self.topk = topk
        self.num_shared_experts = num_shared_experts
        self.t1 = t1
        self.t2 = t2
        self.d = d
        self.t = t
        shared_hidden = max(1, int(channel_in * shared_hidden_ratio))
        self.shared_experts = nn.ModuleList(
            [_SharedFFN(channel_in, shared_hidden) for _ in range(num_shared_experts)]
        )
        self.routed_experts = nn.ModuleList(
            [_DepthwiseConvExpert(channel_in, kernel_size=kernel_size, stride=stride) for _ in range(num_routed_experts)]
        )
        self.expert_centroids = nn.Parameter(torch.randn(num_routed_experts, channel_in) * 0.02)
        self.register_buffer("load_bias", torch.zeros(num_routed_experts))
        self.register_buffer("expert_usage", torch.zeros(num_routed_experts))
        self.bias_update_rate = 0.001

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        x = view_reshape(z, self.view, self.t1, self.t2)
        u = x
        b, n, c = u.shape

        if self.num_shared_experts == 1:
            shared_out = self.shared_experts[0](u)
        else:
            shared_out = self.shared_experts[0](u)
            for ffn in self.shared_experts[1:]:
                shared_out = shared_out + ffn(u)

        sim = torch.matmul(u, self.expert_centroids.transpose(0, 1))
        s = torch.sigmoid(sim)
        biased = s + self.load_bias.unsqueeze(0).unsqueeze(0)
        topk_vals, topk_idx = torch.topk(biased, k=self.topk, dim=-1)
        mask = torch.zeros_like(s)
        mask.scatter_(-1, topk_idx, 1.0)
        gated = s * mask
        denom = gated.sum(dim=-1, keepdim=True).clamp_min(1e-6)
        gates = gated / denom

        if self.training:
            with torch.no_grad():
                usage = mask.mean(dim=(0, 1))
                self.expert_usage.mul_(0.99).add_(usage, alpha=0.01)
                target = float(self.topk) / float(self.num_routed_experts)
                drift = self.expert_usage - target
                self.load_bias.add_(-self.bias_update_rate * drift)

        routed_out = torch.zeros_like(u)
        for i, expert in enumerate(self.routed_experts):
            g_i = gates[..., i:i + 1]
            routed_out = routed_out + g_i * expert(u)

        out = u + shared_out + routed_out
        return view_inverse(out, self.view, self.d, self.t, self.t1, self.t2)
