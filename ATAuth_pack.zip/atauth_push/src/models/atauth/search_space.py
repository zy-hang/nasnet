from __future__ import annotations

import dataclasses
import random
from typing import Sequence


FUSION_VIEWS: tuple[str, ...] = ("GSFF", "GTFF", "LSFF", "LTFF")
ATTENTION_HEADS: tuple[int, ...] = (1, 2, 4, 8)
ATTENTION_HEAD_DIMS: tuple[int, ...] = (8, 16, 24, 32)
DCSMOE_TOTAL_EXPERTS: tuple[int, ...] = (8, 12, 16)
DCSMOE_TOPK: tuple[int, ...] = (1, 2, 3, 4)
OPERATOR_TYPES: tuple[str, ...] = ("attention", "dc_smoe")


def cnn_kernel_sizes() -> tuple[int, ...]:
    return (3, 5, 7)


def cnn_strides() -> tuple[int, ...]:
    return (1, 2)


@dataclasses.dataclass(frozen=True)
class SlotChoice:
    operator: str
    view: str
    num_heads: int
    head_dim: int
    num_experts: int
    topk: int

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class LayerChoice:
    slot_a: SlotChoice
    slot_b: SlotChoice


@dataclasses.dataclass(frozen=True)
class CNNChoice:
    kernel_sizes: tuple[int, ...]
    strides: tuple[int, ...]


@dataclasses.dataclass(frozen=True)
class Architecture:
    layers: tuple[LayerChoice, ...]
    cnn: CNNChoice


def sample_random_slot(rng: random.Random) -> SlotChoice:
    op = rng.choice(OPERATOR_TYPES)
    view = rng.choice(FUSION_VIEWS)
    return SlotChoice(
        operator=op,
        view=view,
        num_heads=rng.choice(ATTENTION_HEADS),
        head_dim=rng.choice(ATTENTION_HEAD_DIMS),
        num_experts=rng.choice(DCSMOE_TOTAL_EXPERTS),
        topk=rng.choice(DCSMOE_TOPK),
    )


def sample_random_layer(rng: random.Random) -> LayerChoice:
    return LayerChoice(slot_a=sample_random_slot(rng), slot_b=sample_random_slot(rng))


def sample_random_cnn(num_stages: int, rng: random.Random) -> CNNChoice:
    ks = tuple(rng.choice(cnn_kernel_sizes()) for _ in range(num_stages))
    ss = tuple(rng.choice(cnn_strides()) for _ in range(num_stages))
    return CNNChoice(kernel_sizes=ks, strides=ss)


def sample_random_architecture(num_layers: int, num_cnn_stages: int, rng: random.Random) -> Architecture:
    layers = tuple(sample_random_layer(rng) for _ in range(num_layers))
    return Architecture(layers=layers, cnn=sample_random_cnn(num_cnn_stages, rng))


def _mutate_slot(slot: SlotChoice, rng: random.Random, decision: str) -> SlotChoice:
    fields = dataclasses.asdict(slot)
    if decision == "operator":
        choices = [c for c in OPERATOR_TYPES if c != slot.operator]
        fields["operator"] = rng.choice(choices)
    elif decision == "view":
        choices = [c for c in FUSION_VIEWS if c != slot.view]
        fields["view"] = rng.choice(choices)
    elif decision == "num_heads":
        choices = [c for c in ATTENTION_HEADS if c != slot.num_heads]
        fields["num_heads"] = rng.choice(choices)
    elif decision == "head_dim":
        choices = [c for c in ATTENTION_HEAD_DIMS if c != slot.head_dim]
        fields["head_dim"] = rng.choice(choices)
    elif decision == "num_experts":
        choices = [c for c in DCSMOE_TOTAL_EXPERTS if c != slot.num_experts]
        fields["num_experts"] = rng.choice(choices)
    elif decision == "topk":
        choices = [c for c in DCSMOE_TOPK if c != slot.topk]
        fields["topk"] = rng.choice(choices)
    return SlotChoice(**fields)


def _mutate_cnn(cnn: CNNChoice, rng: random.Random, decision: str) -> CNNChoice:
    ks = list(cnn.kernel_sizes)
    ss = list(cnn.strides)
    idx = rng.randrange(len(ks))
    if decision == "cnn_kernel":
        choices = [c for c in cnn_kernel_sizes() if c != ks[idx]]
        ks[idx] = rng.choice(choices)
    else:
        choices = [c for c in cnn_strides() if c != ss[idx]]
        ss[idx] = rng.choice(choices)
    return CNNChoice(kernel_sizes=tuple(ks), strides=tuple(ss))


_SLOT_DECISIONS = ("operator", "view", "num_heads", "head_dim", "num_experts", "topk")
_CNN_DECISIONS = ("cnn_kernel", "cnn_stride")


def mutate_architecture(arch: Architecture, rng: random.Random) -> Architecture:
    decision_categories = ("layer_slot", "cnn")
    weights = (len(arch.layers) * 2, 1)
    cat = rng.choices(decision_categories, weights=weights, k=1)[0]
    if cat == "layer_slot":
        layer_idx = rng.randrange(len(arch.layers))
        slot_idx = rng.randrange(2)
        decision = rng.choice(_SLOT_DECISIONS)
        layers = list(arch.layers)
        layer = layers[layer_idx]
        if slot_idx == 0:
            new_layer = LayerChoice(slot_a=_mutate_slot(layer.slot_a, rng, decision), slot_b=layer.slot_b)
        else:
            new_layer = LayerChoice(slot_a=layer.slot_a, slot_b=_mutate_slot(layer.slot_b, rng, decision))
        layers[layer_idx] = new_layer
        return Architecture(layers=tuple(layers), cnn=arch.cnn)
    decision = rng.choice(_CNN_DECISIONS)
    return Architecture(layers=arch.layers, cnn=_mutate_cnn(arch.cnn, rng, decision))


def slot_signature(slot: SlotChoice) -> str:
    if slot.operator == "attention":
        return f"attn-{slot.view}-h{slot.num_heads}-d{slot.head_dim}"
    return f"moe-{slot.view}-e{slot.num_experts}-k{slot.topk}"


def architecture_signature(arch: Architecture) -> str:
    layer_sigs = []
    for i, layer in enumerate(arch.layers):
        layer_sigs.append(f"L{i}[{slot_signature(layer.slot_a)}|{slot_signature(layer.slot_b)}]")
    cnn_sig = "k" + "-".join(str(k) for k in arch.cnn.kernel_sizes) + "_s" + "-".join(str(s) for s in arch.cnn.strides)
    return "::".join(layer_sigs) + "//" + cnn_sig


__all__ = [
    "FUSION_VIEWS",
    "ATTENTION_HEADS",
    "ATTENTION_HEAD_DIMS",
    "DCSMOE_TOTAL_EXPERTS",
    "DCSMOE_TOPK",
    "OPERATOR_TYPES",
    "SlotChoice",
    "LayerChoice",
    "CNNChoice",
    "Architecture",
    "cnn_kernel_sizes",
    "cnn_strides",
    "sample_random_slot",
    "sample_random_layer",
    "sample_random_cnn",
    "sample_random_architecture",
    "mutate_architecture",
    "slot_signature",
    "architecture_signature",
]
