from __future__ import annotations

import torch
import torch.nn as nn

from src.models.atauth.attention import MultiHeadAttention
from src.models.atauth.dc_smoe import DCsMoE
from src.models.atauth.search_space import SlotChoice, LayerChoice


def _channel_dim_for_view(view: str, d: int, t: int, t1: int, t2: int) -> int:
    if view == "GSFF":
        return t
    if view == "GTFF":
        return d
    if view == "LSFF":
        return t2
    if view == "LTFF":
        return d * t1
    raise ValueError(f"unknown view {view}")


def build_slot_module(slot: SlotChoice, d: int, t: int, t1: int, t2: int) -> nn.Module:
    channel_in = _channel_dim_for_view(slot.view, d, t, t1, t2)
    if slot.operator == "attention":
        return MultiHeadAttention(
            view=slot.view,
            channel_in=channel_in,
            num_heads=slot.num_heads,
            head_dim=slot.head_dim,
            t1=t1,
            t2=t2,
            d=d,
            t=t,
        )
    return DCsMoE(
        view=slot.view,
        channel_in=channel_in,
        num_routed_experts=slot.num_experts,
        topk=slot.topk,
        t1=t1,
        t2=t2,
        d=d,
        t=t,
    )


class AdaptiveLayer(nn.Module):
    def __init__(self, layer_choice: LayerChoice, d: int, t: int, t1: int, t2: int):
        super().__init__()
        self.slot_a = build_slot_module(layer_choice.slot_a, d, t, t1, t2)
        self.slot_b = build_slot_module(layer_choice.slot_b, d, t, t1, t2)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        z = self.slot_a(z)
        z = self.slot_b(z)
        return z
