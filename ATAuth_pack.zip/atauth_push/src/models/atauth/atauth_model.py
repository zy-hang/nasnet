from __future__ import annotations

import torch
import torch.nn as nn

from src.models.atauth.adaptive_layer import AdaptiveLayer
from src.models.atauth.cnn_extractor import PersonalizedCNNExtractor
from src.models.atauth.encode import ReshapeEncode
from src.models.atauth.fm import FactorizationMachineHead
from src.models.atauth.search_space import Architecture


class ATAuthModel(nn.Module):
    def __init__(self, arch: Architecture, d: int, t: int, t1: int, t2: int, fm_k: int = 8, num_classes: int = 2):
        super().__init__()
        assert t == t1 * t2, f"T={t} must equal T1*T2={t1*t2}"
        self.d = d
        self.t = t
        self.t1 = t1
        self.t2 = t2
        self.encode = ReshapeEncode(num_channels=d)
        self.layers = nn.ModuleList(
            [AdaptiveLayer(layer, d=d, t=t, t1=t1, t2=t2) for layer in arch.layers]
        )
        self.cnn = PersonalizedCNNExtractor(cnn=arch.cnn, in_channels=d, time_length=t)
        self.head = FactorizationMachineHead(in_dim=self.cnn.out_dim, k=fm_k, num_classes=num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encode(x)
        for layer in self.layers:
            z = layer(z)
        feat = self.cnn(z)
        return self.head(feat)
