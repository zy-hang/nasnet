from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class ReshapeEncode(nn.Module):
    def __init__(self, num_channels: int, kernel_size: int = 3):
        super().__init__()
        pad = (kernel_size - 1) // 2
        self.conv = nn.Conv1d(num_channels, num_channels, kernel_size=kernel_size, padding=pad)
        self.fc = nn.Linear(num_channels, num_channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = x.transpose(1, 2)
        z = F.relu(self.conv(z))
        z = z.transpose(1, 2)
        z = F.silu(self.fc(z))
        z = z.transpose(1, 2)
        return z
