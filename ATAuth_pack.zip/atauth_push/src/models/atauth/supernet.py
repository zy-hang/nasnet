from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.models.atauth.adaptive_layer import build_slot_module
from src.models.atauth.cnn_extractor import _conv_out_length, _funnel_widths
from src.models.atauth.encode import ReshapeEncode
from src.models.atauth.fm import FactorizationMachineHead
from src.models.atauth.search_space import (
    ATTENTION_HEADS,
    ATTENTION_HEAD_DIMS,
    DCSMOE_TOPK,
    DCSMOE_TOTAL_EXPERTS,
    FUSION_VIEWS,
    Architecture,
    CNNChoice,
    LayerChoice,
    SlotChoice,
    cnn_kernel_sizes,
    cnn_strides,
    slot_signature,
)


def _all_slot_choices() -> list[SlotChoice]:
    choices: list[SlotChoice] = []
    for view in FUSION_VIEWS:
        for h in ATTENTION_HEADS:
            for hd in ATTENTION_HEAD_DIMS:
                choices.append(SlotChoice(
                    operator="attention",
                    view=view,
                    num_heads=h,
                    head_dim=hd,
                    num_experts=DCSMOE_TOTAL_EXPERTS[0],
                    topk=DCSMOE_TOPK[0],
                ))
        for ne in DCSMOE_TOTAL_EXPERTS:
            for k in DCSMOE_TOPK:
                choices.append(SlotChoice(
                    operator="dc_smoe",
                    view=view,
                    num_heads=ATTENTION_HEADS[0],
                    head_dim=ATTENTION_HEAD_DIMS[0],
                    num_experts=ne,
                    topk=k,
                ))
    return choices


class _SlotBank(nn.Module):
    def __init__(self, d: int, t: int, t1: int, t2: int):
        super().__init__()
        self.choices = _all_slot_choices()
        self.modules_dict = nn.ModuleDict()
        for choice in self.choices:
            sig = slot_signature(choice)
            self.modules_dict[sig] = build_slot_module(choice, d=d, t=t, t1=t1, t2=t2)

    def forward(self, z: torch.Tensor, slot: SlotChoice) -> torch.Tensor:
        return self.modules_dict[slot_signature(slot)](z)


def _stage_key(kernel: int, stride: int) -> str:
    return f"k{kernel}s{stride}"


class _CNNStageBank(nn.Module):
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.modules_dict = nn.ModuleDict()
        for ks in cnn_kernel_sizes():
            for ss in cnn_strides():
                pad = (ks - 1) // 2
                self.modules_dict[_stage_key(ks, ss)] = nn.Sequential(
                    nn.Conv1d(in_ch, out_ch, kernel_size=ks, stride=ss, padding=pad),
                    nn.BatchNorm1d(out_ch),
                    nn.ReLU(inplace=True),
                )

    def forward(self, x: torch.Tensor, kernel: int, stride: int) -> torch.Tensor:
        return self.modules_dict[_stage_key(kernel, stride)](x)


class _CNNBank(nn.Module):
    def __init__(self, d: int, time_length: int, num_stages: int = 4):
        super().__init__()
        self.num_stages = num_stages
        widths = _funnel_widths(d, num_stages)
        self.stages = nn.ModuleList(
            [_CNNStageBank(in_ch=widths[i], out_ch=widths[i + 1]) for i in range(num_stages)]
        )
        self.widths = widths
        self.time_lengths = self._compute_time_lengths(time_length, num_stages)
        self.out_dim_for: dict[str, int] = {}
        self._precompute_out_dims()

    def _compute_time_lengths(self, time_length: int, num_stages: int) -> dict[str, list[int]]:
        out: dict[str, list[int]] = {}
        for ks in cnn_kernel_sizes():
            for ss in cnn_strides():
                lengths = [time_length]
                cur = time_length
                pad = (ks - 1) // 2
                for _ in range(num_stages):
                    cur = _conv_out_length(cur, ks, ss, pad)
                    lengths.append(cur)
                out[_stage_key(ks, ss)] = lengths
        return out

    def _precompute_out_dims(self) -> None:
        for ks in cnn_kernel_sizes():
            for ss in cnn_strides():
                key = _stage_key(ks, ss)
                lengths = self.time_lengths[key]
                self.out_dim_for[key] = self.widths[-1] * lengths[-1]
        max_dim = max(self.out_dim_for.values())
        for ks in cnn_kernel_sizes():
            for ss in cnn_strides():
                self.out_dim_for[_stage_key(ks, ss)] = max_dim
        self.unified_out_dim = max_dim

    def forward(self, z: torch.Tensor, cnn: CNNChoice) -> torch.Tensor:
        x = z
        for stage_idx in range(self.num_stages):
            ks = cnn.kernel_sizes[stage_idx]
            ss = cnn.strides[stage_idx]
            x = self.stages[stage_idx](x, ks, ss)
        feat = x.flatten(start_dim=1)
        if feat.shape[1] != self.unified_out_dim:
            feat = F.pad(feat, (0, self.unified_out_dim - feat.shape[1]))
        return feat


class ATAuthSupernet(nn.Module):
    def __init__(self, num_layers: int, d: int, t: int, t1: int, t2: int, fm_k: int = 8, num_classes: int = 2, fm_in_dim: int = 64):
        super().__init__()
        assert t == t1 * t2
        self.num_layers = num_layers
        self.d = d
        self.t = t
        self.t1 = t1
        self.t2 = t2
        self.fm_in_dim = fm_in_dim
        self.encode = ReshapeEncode(num_channels=d)
        self.layer_banks = nn.ModuleList(
            [nn.ModuleList([_SlotBank(d, t, t1, t2), _SlotBank(d, t, t1, t2)]) for _ in range(num_layers)]
        )
        self.cnn_bank = _CNNBank(d=d, time_length=t, num_stages=4)
        self.feat_proj = nn.Linear(self.cnn_bank.unified_out_dim, fm_in_dim)
        self.head = FactorizationMachineHead(in_dim=fm_in_dim, k=fm_k, num_classes=num_classes)

    def forward(self, x: torch.Tensor, arch: Architecture) -> torch.Tensor:
        z = self.encode(x)
        for layer_idx in range(self.num_layers):
            slot_a = arch.layers[layer_idx].slot_a
            slot_b = arch.layers[layer_idx].slot_b
            z = self.layer_banks[layer_idx][0](z, slot_a)
            z = self.layer_banks[layer_idx][1](z, slot_b)
        feat = self.cnn_bank(z, arch.cnn)
        feat = self.feat_proj(feat)
        return self.head(feat)

    def parameters_for_path(self, arch: Architecture):
        params = list(self.encode.parameters())
        for layer_idx in range(self.num_layers):
            slot_a = arch.layers[layer_idx].slot_a
            slot_b = arch.layers[layer_idx].slot_b
            sig_a = slot_signature(slot_a)
            sig_b = slot_signature(slot_b)
            params.extend(self.layer_banks[layer_idx][0].modules_dict[sig_a].parameters())
            params.extend(self.layer_banks[layer_idx][1].modules_dict[sig_b].parameters())
        for stage_idx in range(self.cnn_bank.num_stages):
            ks = arch.cnn.kernel_sizes[stage_idx]
            ss = arch.cnn.strides[stage_idx]
            params.extend(self.cnn_bank.stages[stage_idx].modules_dict[_stage_key(ks, ss)].parameters())
        params.extend(self.feat_proj.parameters())
        params.extend(self.head.parameters())
        return params
