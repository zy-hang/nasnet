from __future__ import annotations

import torch


def view_reshape(z: torch.Tensor, view: str, t1: int, t2: int) -> torch.Tensor:
    b, d, t = z.shape
    if view == "GSFF":
        return z
    if view == "GTFF":
        return z.transpose(1, 2).contiguous()
    if view == "LSFF":
        return z.reshape(b, d, t1, t2).reshape(b, d * t1, t2)
    if view == "LTFF":
        ltff_t1 = t2
        ltff_t2 = t1
        out = z.reshape(b, d, ltff_t1, ltff_t2).permute(0, 2, 1, 3).contiguous().reshape(b, ltff_t1, d * ltff_t2)
        return out
    raise ValueError(f"unknown view {view}")


def view_inverse(y: torch.Tensor, view: str, d: int, t: int, t1: int, t2: int) -> torch.Tensor:
    b = y.shape[0]
    if view == "GSFF":
        return y
    if view == "GTFF":
        return y.transpose(1, 2).contiguous()
    if view == "LSFF":
        return y.reshape(b, d, t1, t2).reshape(b, d, t)
    if view == "LTFF":
        ltff_t1 = t2
        ltff_t2 = t1
        out = y.reshape(b, ltff_t1, d, ltff_t2).permute(0, 2, 1, 3).contiguous().reshape(b, d, t)
        return out
    raise ValueError(f"unknown view {view}")
