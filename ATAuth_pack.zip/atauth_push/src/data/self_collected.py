from __future__ import annotations

import os
import numpy as np

from src.data.base_dataset import axis_wise_min_max


class SelfCollectedDataset:
    def __init__(self, root: str):
        self.root = root

    def load_user_streams(self) -> dict[int, np.ndarray]:
        flat: dict[int, np.ndarray] = {}
        for fname in sorted(os.listdir(self.root)):
            if not fname.endswith(".npy"):
                continue
            try:
                uid = int(os.path.splitext(fname)[0].split("_")[-1])
            except ValueError:
                continue
            stream = np.load(os.path.join(self.root, fname)).astype(np.float32)
            if stream.ndim != 2 or stream.shape[1] != 9:
                raise ValueError(f"self-collected stream for user {uid} must be [T, 9], got {stream.shape}")
            flat[uid] = axis_wise_min_max(stream).astype(np.float32)
        return flat
