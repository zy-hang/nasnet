from __future__ import annotations

import numpy as np


def inject_gaussian_mimic(windows: np.ndarray, max_std: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    std = rng.uniform(0.0, max_std, size=(windows.shape[0], 1, 1)).astype(np.float32)
    noise = rng.standard_normal(size=windows.shape).astype(np.float32) * std
    return (windows + noise).astype(np.float32)
