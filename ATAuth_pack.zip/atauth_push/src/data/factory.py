from __future__ import annotations

from src.data.uci_har import UCIHARDataset
from src.data.wisdm_harb import WISDMHARBDataset
from src.data.self_collected import SelfCollectedDataset


_REGISTRY = {
    "uci_har": UCIHARDataset,
    "wisdm_harb": WISDMHARBDataset,
    "self_collected": SelfCollectedDataset,
}


def build_dataset(name: str, root: str):
    if name not in _REGISTRY:
        raise KeyError(f"unknown dataset {name}, choices: {list(_REGISTRY.keys())}")
    return _REGISTRY[name](root)
