from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import Dataset


def axis_wise_min_max(stream: np.ndarray) -> np.ndarray:
    mins = stream.min(axis=0, keepdims=True)
    maxs = stream.max(axis=0, keepdims=True)
    denom = np.where((maxs - mins) > 0, (maxs - mins), 1.0)
    return (stream - mins) / denom


def build_user_split(stream: np.ndarray, train_ratio: float) -> tuple[np.ndarray, np.ndarray]:
    cut = int(stream.shape[0] * train_ratio)
    return stream[:cut], stream[cut:]


def sample_train_windows(stream: np.ndarray, num_windows: int, window_length: int, rng: np.random.Generator) -> np.ndarray:
    max_start = stream.shape[0] - window_length
    starts = rng.integers(0, max_start + 1, size=num_windows)
    out = np.empty((num_windows, window_length, stream.shape[1]), dtype=np.float32)
    for i, s in enumerate(starts):
        out[i] = stream[s:s + window_length]
    return out


def segment_test_windows(stream: np.ndarray, num_windows: int, window_length: int) -> np.ndarray:
    total = num_windows * window_length
    if stream.shape[0] < total:
        num_windows = stream.shape[0] // window_length
        total = num_windows * window_length
    return stream[:total].reshape(num_windows, window_length, stream.shape[1]).astype(np.float32)


def build_authentication_pairs(
    user_streams: dict[int, np.ndarray],
    legitimate_user: int,
    train_ratio: float,
    num_train_windows: int,
    num_test_windows: int,
    window_length: int,
    impostor_train_users: list[int],
    impostor_test_users: list[int],
    pos_neg_ratio_train: tuple[int, int],
    pos_neg_ratio_test: tuple[int, int],
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)

    legit_stream = user_streams[legitimate_user]
    legit_train_stream, legit_test_stream = build_user_split(legit_stream, train_ratio)

    legit_train = sample_train_windows(legit_train_stream, num_train_windows, window_length, rng)
    legit_test = segment_test_windows(legit_test_stream, num_test_windows, window_length)

    pos_train_count = legit_train.shape[0]
    pos_test_count = legit_test.shape[0]

    p_tr, n_tr = pos_neg_ratio_train
    p_te, n_te = pos_neg_ratio_test

    neg_train_count = pos_train_count * n_tr // p_tr
    neg_test_count = pos_test_count * n_te // p_te

    impostor_train_pool = []
    for uid in impostor_train_users:
        if uid not in user_streams:
            continue
        u_stream = user_streams[uid]
        u_train_stream, _ = build_user_split(u_stream, train_ratio)
        per_user = max(1, neg_train_count // max(1, len(impostor_train_users)))
        impostor_train_pool.append(sample_train_windows(u_train_stream, per_user, window_length, rng))
    neg_train = np.concatenate(impostor_train_pool, axis=0)[:neg_train_count]

    impostor_test_pool = []
    for uid in impostor_test_users:
        if uid not in user_streams:
            continue
        u_stream = user_streams[uid]
        _, u_test_stream = build_user_split(u_stream, train_ratio)
        per_user = max(1, neg_test_count // max(1, len(impostor_test_users)))
        impostor_test_pool.append(segment_test_windows(u_test_stream, per_user, window_length))
    neg_test = np.concatenate(impostor_test_pool, axis=0)[:neg_test_count]

    train_x = np.concatenate([legit_train, neg_train], axis=0).astype(np.float32)
    train_y = np.concatenate([
        np.ones(legit_train.shape[0], dtype=np.int64),
        np.zeros(neg_train.shape[0], dtype=np.int64),
    ], axis=0)

    test_x = np.concatenate([legit_test, neg_test], axis=0).astype(np.float32)
    test_y = np.concatenate([
        np.ones(legit_test.shape[0], dtype=np.int64),
        np.zeros(neg_test.shape[0], dtype=np.int64),
    ], axis=0)

    perm = rng.permutation(train_x.shape[0])
    train_x = train_x[perm]
    train_y = train_y[perm]

    return train_x, train_y, test_x, test_y


class BaseSensorDataset(Dataset):
    def __init__(self, x: np.ndarray, y: np.ndarray):
        self.x = torch.from_numpy(x)
        self.y = torch.from_numpy(y)

    def __len__(self) -> int:
        return self.x.shape[0]

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self.x[idx], self.y[idx]
