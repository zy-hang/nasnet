from __future__ import annotations

import os
import numpy as np

from src.data.base_dataset import axis_wise_min_max


_FEATURE_FILES = (
    "body_acc_x",
    "body_acc_y",
    "body_acc_z",
    "body_gyro_x",
    "body_gyro_y",
    "body_gyro_z",
    "total_acc_x",
    "total_acc_y",
    "total_acc_z",
)


def _load_signal(path: str, name: str, split: str) -> np.ndarray:
    fname = f"{name}_{split}.txt"
    full = os.path.join(path, "Inertial Signals", fname)
    return np.loadtxt(full, dtype=np.float32)


def _load_subjects(path: str, split: str) -> np.ndarray:
    return np.loadtxt(os.path.join(path, f"subject_{split}.txt"), dtype=np.int64)


class UCIHARDataset:
    def __init__(self, root: str, channels: int = 9):
        self.root = root
        self.channels = channels

    def load_user_streams(self) -> dict[int, np.ndarray]:
        user_streams: dict[int, list[np.ndarray]] = {}
        for split in ("train", "test"):
            split_dir = os.path.join(self.root, split)
            subjects = _load_subjects(split_dir, split)
            arrays = [
                _load_signal(split_dir, name, split)[:, :, None]
                for name in _FEATURE_FILES[: self.channels]
            ]
            stacked = np.concatenate(arrays, axis=2)
            n_samples, win_len, c = stacked.shape
            for sub_id in np.unique(subjects):
                mask = subjects == sub_id
                user_block = stacked[mask].reshape(-1, c)
                user_streams.setdefault(int(sub_id), []).append(user_block)
        flat: dict[int, np.ndarray] = {}
        for uid, blocks in user_streams.items():
            stream = np.concatenate(blocks, axis=0)
            flat[uid] = axis_wise_min_max(stream).astype(np.float32)
        return flat
