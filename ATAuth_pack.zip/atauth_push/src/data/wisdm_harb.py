from __future__ import annotations

import os
import numpy as np
import pandas as pd

from src.data.base_dataset import axis_wise_min_max


_PHONE_ACCEL_DIR = os.path.join("raw", "phone", "accel")
_PHONE_GYRO_DIR = os.path.join("raw", "phone", "gyro")


def _read_one(path: str) -> pd.DataFrame:
    rows = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip().rstrip(";")
            if not line:
                continue
            parts = line.split(",")
            if len(parts) < 6:
                continue
            try:
                rows.append((int(parts[0]), parts[1], int(parts[2]), float(parts[3]), float(parts[4]), float(parts[5])))
            except ValueError:
                continue
    return pd.DataFrame(rows, columns=["subject", "activity", "ts", "x", "y", "z"])


class WISDMHARBDataset:
    def __init__(self, root: str):
        self.root = root

    def load_user_streams(self) -> dict[int, np.ndarray]:
        accel_dir = os.path.join(self.root, _PHONE_ACCEL_DIR)
        gyro_dir = os.path.join(self.root, _PHONE_GYRO_DIR)

        accel_frames = {}
        for fname in sorted(os.listdir(accel_dir)):
            if not fname.endswith(".txt"):
                continue
            df = _read_one(os.path.join(accel_dir, fname))
            if df.empty:
                continue
            sub = int(df["subject"].iloc[0])
            df_sorted = df.sort_values("ts").reset_index(drop=True)
            accel_frames[sub] = df_sorted

        gyro_frames = {}
        for fname in sorted(os.listdir(gyro_dir)):
            if not fname.endswith(".txt"):
                continue
            df = _read_one(os.path.join(gyro_dir, fname))
            if df.empty:
                continue
            sub = int(df["subject"].iloc[0])
            df_sorted = df.sort_values("ts").reset_index(drop=True)
            gyro_frames[sub] = df_sorted

        flat: dict[int, np.ndarray] = {}
        for sub in accel_frames.keys() & gyro_frames.keys():
            a = accel_frames[sub][["x", "y", "z"]].to_numpy(dtype=np.float32)
            g = gyro_frames[sub][["x", "y", "z"]].to_numpy(dtype=np.float32)
            n = min(a.shape[0], g.shape[0])
            stream = np.concatenate([a[:n], g[:n]], axis=1)
            flat[sub] = axis_wise_min_max(stream).astype(np.float32)
        return flat
