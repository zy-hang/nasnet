from __future__ import annotations

from typing import Callable

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from src.evaluation.metrics import compute_metrics
from src.models.atauth.atauth_model import ATAuthModel
from src.models.atauth.search_space import Architecture


def retrain_architecture(
    arch: Architecture,
    train_loader: DataLoader,
    val_loader: DataLoader,
    num_epochs: int,
    lr: float,
    d: int,
    t: int,
    t1: int,
    t2: int,
    device: torch.device,
    log_fn: Callable[[str], None] = print,
) -> ATAuthModel:
    model = ATAuthModel(arch=arch, d=d, t=t, t1=t1, t2=t2).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    for epoch in range(num_epochs):
        model.train()
        running = 0.0
        seen = 0
        for bx, by in train_loader:
            bx = bx.to(device)
            by = by.to(device)
            logits = model(bx)
            loss = criterion(logits, by)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            running += float(loss.detach()) * bx.size(0)
            seen += bx.size(0)
        avg = running / max(1, seen)
        log_fn(f"[retrain] epoch {epoch+1}/{num_epochs} train_loss={avg:.4f}")
    return model


def evaluate_model(model: ATAuthModel, test_loader: DataLoader, device: torch.device) -> dict:
    model.eval()
    pos_scores: list[float] = []
    preds: list[int] = []
    labels: list[int] = []
    with torch.no_grad():
        for bx, by in test_loader:
            bx = bx.to(device)
            logits = model(bx)
            probs = torch.softmax(logits, dim=-1)
            pos_scores.extend(probs[:, 1].cpu().tolist())
            preds.extend(logits.argmax(dim=-1).cpu().tolist())
            labels.extend(by.tolist())
    return compute_metrics(labels, preds, pos_scores)
