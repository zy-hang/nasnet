from __future__ import annotations

import collections
import random
from typing import Callable

import torch
from torch.utils.data import DataLoader

from src.evaluation.metrics import compute_f1
from src.models.atauth.flops import estimate_flops, estimate_latency_proxy
from src.models.atauth.search_space import Architecture, mutate_architecture, sample_random_architecture
from src.models.atauth.supernet import ATAuthSupernet


def _evaluate_arch_f1(supernet: ATAuthSupernet, arch: Architecture, val_loader: DataLoader, device: torch.device) -> float:
    supernet.eval()
    preds_all: list[int] = []
    labels_all: list[int] = []
    with torch.no_grad():
        for batch_x, batch_y in val_loader:
            batch_x = batch_x.to(device)
            logits = supernet(batch_x, arch)
            preds = logits.argmax(dim=-1).cpu().tolist()
            preds_all.extend(preds)
            labels_all.extend(batch_y.tolist())
    return compute_f1(labels_all, preds_all)


def _is_feasible(arch: Architecture, d: int, t: int, t1: int, t2: int, flops_budget: float, latency_budget: float) -> bool:
    flops = estimate_flops(arch, d, t, t1, t2)
    if flops > flops_budget:
        return False
    latency = estimate_latency_proxy(arch, d, t, t1, t2)
    if latency > latency_budget:
        return False
    return True


def regularized_evolution(
    supernet: ATAuthSupernet,
    val_loader: DataLoader,
    num_layers: int,
    num_cnn_stages: int,
    d: int,
    t: int,
    t1: int,
    t2: int,
    population_size: int,
    tournament_size: int,
    num_cycles: int,
    flops_budget: float,
    latency_budget: float,
    device: torch.device,
    seed: int,
    log_fn: Callable[[str], None] = print,
) -> Architecture:
    rng = random.Random(seed)
    population: collections.deque = collections.deque(maxlen=population_size)
    history: list[tuple[Architecture, float]] = []

    initialized = 0
    attempts = 0
    while initialized < population_size and attempts < population_size * 50:
        attempts += 1
        arch = sample_random_architecture(num_layers=num_layers, num_cnn_stages=num_cnn_stages, rng=rng)
        if not _is_feasible(arch, d, t, t1, t2, flops_budget, latency_budget):
            continue
        f1 = _evaluate_arch_f1(supernet, arch, val_loader, device)
        population.append((arch, f1))
        history.append((arch, f1))
        initialized += 1
    if initialized == 0:
        raise RuntimeError("no feasible architecture found during initialization")

    for cycle in range(num_cycles):
        sample = rng.sample(list(population), min(tournament_size, len(population)))
        parent = max(sample, key=lambda item: item[1])[0]
        child: Architecture | None = None
        for _ in range(50):
            candidate = mutate_architecture(parent, rng)
            if _is_feasible(candidate, d, t, t1, t2, flops_budget, latency_budget):
                child = candidate
                break
        if child is None:
            continue
        f1 = _evaluate_arch_f1(supernet, child, val_loader, device)
        population.append((child, f1))
        history.append((child, f1))
        if (cycle + 1) % max(1, num_cycles // 10) == 0:
            best = max(history, key=lambda item: item[1])
            log_fn(f"[evo] cycle {cycle+1}/{num_cycles} pool={len(population)} best_f1={best[1]:.4f}")

    best_arch, best_f1 = max(history, key=lambda item: item[1])
    log_fn(f"[evo] selected best_f1={best_f1:.4f}")
    return best_arch
