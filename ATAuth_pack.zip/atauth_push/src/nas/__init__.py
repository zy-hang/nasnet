from src.nas.supernet_train import train_supernet
from src.nas.evo_search import regularized_evolution
