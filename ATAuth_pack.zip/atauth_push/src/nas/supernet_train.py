from __future__ import annotations

import random
from typing import Callable

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from src.models.atauth.search_space import Architecture, sample_random_architecture
from src.models.atauth.supernet import ATAuthSupernet


class _PerParamAdam:
    def __init__(self, params: list[torch.nn.Parameter], lr: float, betas=(0.9, 0.999), eps: float = 1e-8):
        self.lr = lr
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.state: dict[int, dict] = {}
        for p in params:
            pid = id(p)
            self.state[pid] = {
                "step": 0,
                "exp_avg": torch.zeros_like(p, requires_grad=False),
                "exp_avg_sq": torch.zeros_like(p, requires_grad=False),
            }

    def step(self, params: list[torch.nn.Parameter]) -> None:
        for p in params:
            if p.grad is None:
                continue
            pid = id(p)
            st = self.state[pid]
            st["step"] += 1
            t = st["step"]
            grad = p.grad.detach()
            st["exp_avg"].mul_(self.beta1).add_(grad, alpha=1 - self.beta1)
            st["exp_avg_sq"].mul_(self.beta2).addcmul_(grad, grad, value=1 - self.beta2)
            bias1 = 1 - self.beta1 ** t
            bias2 = 1 - self.beta2 ** t
            denom = (st["exp_avg_sq"].sqrt() / (bias2 ** 0.5)).add_(self.eps)
            step_size = self.lr / bias1
            p.data.addcdiv_(st["exp_avg"], denom, value=-step_size)

    def zero_grad(self, params: list[torch.nn.Parameter]) -> None:
        for p in params:
            if p.grad is not None:
                p.grad.detach_()
                p.grad.zero_()


def train_supernet(
    supernet: ATAuthSupernet,
    train_loader: DataLoader,
    val_loader: DataLoader,
    num_epochs: int,
    lr: float,
    num_layers: int,
    num_cnn_stages: int,
    device: torch.device,
    seed: int,
    log_fn: Callable[[str], None] = print,
) -> ATAuthSupernet:
    rng = random.Random(seed)
    supernet.to(device)
    optimizer = _PerParamAdam(list(supernet.parameters()), lr=lr)
    criterion = nn.CrossEntropyLoss()

    for epoch in range(num_epochs):
        supernet.train()
        running_loss = 0.0
        seen = 0
        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            arch = sample_random_architecture(num_layers=num_layers, num_cnn_stages=num_cnn_stages, rng=rng)
            path_params = supernet.parameters_for_path(arch)
            for p in supernet.parameters():
                if p.grad is not None:
                    p.grad.detach_()
                    p.grad.zero_()
            logits = supernet(batch_x, arch)
            loss = criterion(logits, batch_y)
            loss.backward()
            optimizer.step(path_params)
            running_loss += float(loss.detach()) * batch_x.size(0)
            seen += batch_x.size(0)
        avg_train = running_loss / max(1, seen)

        supernet.eval()
        val_loss = 0.0
        val_seen = 0
        with torch.no_grad():
            for batch_x, batch_y in val_loader:
                batch_x = batch_x.to(device)
                batch_y = batch_y.to(device)
                arch = sample_random_architecture(num_layers=num_layers, num_cnn_stages=num_cnn_stages, rng=rng)
                logits = supernet(batch_x, arch)
                loss = criterion(logits, batch_y)
                val_loss += float(loss.detach()) * batch_x.size(0)
                val_seen += batch_x.size(0)
        avg_val = val_loss / max(1, val_seen)
        log_fn(f"[supernet] epoch {epoch+1}/{num_epochs} train_loss={avg_train:.4f} val_loss={avg_val:.4f}")

    return supernet
