from __future__ import annotations

from typing import Sequence

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_curve


def compute_eer(scores: Sequence[float], labels: Sequence[int]) -> tuple[float, float]:
    fpr, tpr, thresholds = roc_curve(labels, scores)
    fnr = 1 - tpr
    diffs = np.abs(fnr - fpr)
    idx = int(np.argmin(diffs))
    eer = float((fnr[idx] + fpr[idx]) / 2.0)
    return eer, float(thresholds[idx])


def compute_far_frr(labels: Sequence[int], preds: Sequence[int]) -> tuple[float, float]:
    labels_arr = np.asarray(labels)
    preds_arr = np.asarray(preds)
    pos_mask = labels_arr == 1
    neg_mask = labels_arr == 0
    if neg_mask.sum() == 0:
        far = 0.0
    else:
        far = float((preds_arr[neg_mask] == 1).mean())
    if pos_mask.sum() == 0:
        frr = 0.0
    else:
        frr = float((preds_arr[pos_mask] == 0).mean())
    return far, frr


def compute_f1(labels: Sequence[int], preds: Sequence[int]) -> float:
    if len(labels) == 0:
        return 0.0
    return float(f1_score(labels, preds, average="binary", zero_division=0))


def compute_metrics(labels: Sequence[int], preds: Sequence[int], pos_scores: Sequence[float]) -> dict:
    acc = float(accuracy_score(labels, preds))
    f1 = compute_f1(labels, preds)
    far, frr = compute_far_frr(labels, preds)
    if len(set(labels)) >= 2:
        eer, threshold = compute_eer(pos_scores, labels)
    else:
        eer, threshold = 0.0, 0.5
    return {
        "accuracy": acc,
        "f1": f1,
        "eer": eer,
        "far": far,
        "frr": frr,
        "eer_threshold": threshold,
    }
