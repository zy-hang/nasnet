from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import DataLoader

from src.data.base_dataset import BaseSensorDataset
from src.data.mimic import inject_gaussian_mimic
from src.evaluation.metrics import compute_metrics


def run_mimic_attack(
    model: torch.nn.Module,
    legitimate_test_x: np.ndarray,
    max_noise_std: float,
    seed: int,
    device: torch.device,
    batch_size: int,
) -> dict:
    model.eval()
    n = legitimate_test_x.shape[0]
    half = n // 2

    rng = np.random.default_rng(seed)
    perm = rng.permutation(n)
    real_part = legitimate_test_x[perm[:half]]
    mimic_source = legitimate_test_x[perm[half:half * 2]] if half * 2 <= n else legitimate_test_x[perm[half:]]
    mimic_part = inject_gaussian_mimic(mimic_source, max_noise_std, seed=seed)

    test_x = np.concatenate([real_part, mimic_part], axis=0).astype(np.float32)
    test_y = np.concatenate([
        np.ones(real_part.shape[0], dtype=np.int64),
        np.zeros(mimic_part.shape[0], dtype=np.int64),
    ], axis=0)

    loader = DataLoader(BaseSensorDataset(test_x, test_y), batch_size=batch_size, shuffle=False)
    pos_scores: list[float] = []
    preds: list[int] = []
    labels: list[int] = []
    with torch.no_grad():
        for bx, by in loader:
            bx = bx.to(device)
            logits = model(bx)
            probs = torch.softmax(logits, dim=-1)
            pos_scores.extend(probs[:, 1].cpu().tolist())
            preds.extend(logits.argmax(dim=-1).cpu().tolist())
            labels.extend(by.tolist())
    return compute_metrics(labels, preds, pos_scores)
