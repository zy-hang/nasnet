from __future__ import annotations

import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import random
import numpy as np
import torch
from torch.utils.data import DataLoader

from src.data import BaseSensorDataset
from src.evaluation import run_mimic_attack
from src.models.atauth import (
    ATAuthModel,
    ATAuthSupernet,
    sample_random_architecture,
    estimate_flops,
)
from src.nas import regularized_evolution, train_supernet
from src.training import evaluate_model, retrain_architecture


def _make_synthetic(num_users: int, stream_len: int, channels: int, seed: int) -> dict[int, np.ndarray]:
    rng = np.random.default_rng(seed)
    streams = {}
    for uid in range(num_users):
        base = rng.standard_normal((stream_len, channels)).astype(np.float32) * 0.1
        signature = rng.standard_normal((channels,)).astype(np.float32) * 0.5
        base += signature[None, :]
        streams[uid] = ((base - base.min(axis=0, keepdims=True)) / (base.max(axis=0, keepdims=True) - base.min(axis=0, keepdims=True) + 1e-6)).astype(np.float32)
    return streams


def _build_pairs(streams, legit_uid, train_ratio, win_len, num_train, num_test, imp_train, imp_test, seed):
    from src.data.base_dataset import build_authentication_pairs
    return build_authentication_pairs(
        user_streams=streams,
        legitimate_user=legit_uid,
        train_ratio=train_ratio,
        num_train_windows=num_train,
        num_test_windows=num_test,
        window_length=win_len,
        impostor_train_users=imp_train,
        impostor_test_users=imp_test,
        pos_neg_ratio_train=(1, 2),
        pos_neg_ratio_test=(2, 1),
        seed=seed,
    )


def main():
    seed = 42
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    d = 9
    t = 200
    t1 = 5
    t2 = 40
    win_len = t
    device = torch.device("cpu")

    print("[1/6] Build synthetic dataset (6 users, stream length 2400)", flush=True)
    streams = _make_synthetic(num_users=6, stream_len=2400, channels=d, seed=seed)
    legit = 0
    imp_train = [1, 2]
    imp_test = [3, 4, 5]

    train_x, train_y, test_x, test_y = _build_pairs(
        streams, legit, 0.8, win_len, num_train=24, num_test=8, imp_train=imp_train, imp_test=imp_test, seed=seed,
    )
    print(f"   train_x shape: {train_x.shape}, test_x shape: {test_x.shape}", flush=True)

    val_split = max(1, len(train_x) // 5)
    val_x, val_y = train_x[:val_split], train_y[:val_split]
    train_x, train_y = train_x[val_split:], train_y[val_split:]

    train_loader = DataLoader(BaseSensorDataset(train_x, train_y), batch_size=4, shuffle=True)
    val_loader = DataLoader(BaseSensorDataset(val_x, val_y), batch_size=4, shuffle=False)
    test_loader = DataLoader(BaseSensorDataset(test_x, test_y), batch_size=4, shuffle=False)

    print("[2/6] Forward sanity check on a random architecture", flush=True)
    rng = random.Random(seed)
    arch = sample_random_architecture(num_layers=2, num_cnn_stages=4, rng=rng)
    model = ATAuthModel(arch=arch, d=d, t=t, t1=t1, t2=t2)
    x = torch.randn(2, t, d)
    logits = model(x)
    assert logits.shape == (2, 2), f"unexpected output shape {logits.shape}"
    print(f"   ATAuthModel forward OK, logits shape = {tuple(logits.shape)}", flush=True)

    flops = estimate_flops(arch, d, t, t1, t2)
    print(f"   estimated FLOPs = {flops:.3e}", flush=True)

    print("[3/6] Forward sanity check on the supernet across 5 random paths", flush=True)
    supernet = ATAuthSupernet(num_layers=2, d=d, t=t, t1=t1, t2=t2)
    for i in range(5):
        a = sample_random_architecture(num_layers=2, num_cnn_stages=4, rng=rng)
        out = supernet(x, a)
        assert out.shape == (2, 2)
    print("   Supernet forward OK across 5 paths", flush=True)

    print("[4/6] Train supernet for 1 epoch on synthetic data", flush=True)
    train_supernet(
        supernet=supernet,
        train_loader=train_loader,
        val_loader=val_loader,
        num_epochs=1,
        lr=1e-3,
        num_layers=2,
        num_cnn_stages=4,
        device=device,
        seed=seed,
    )

    print("[5/6] Run mini regularized evolution (population 4, cycles 3)", flush=True)
    best_arch = regularized_evolution(
        supernet=supernet,
        val_loader=val_loader,
        num_layers=2,
        num_cnn_stages=4,
        d=d,
        t=t,
        t1=t1,
        t2=t2,
        population_size=4,
        tournament_size=2,
        num_cycles=3,
        flops_budget=1e10,
        latency_budget=1e10,
        device=device,
        seed=seed + 1,
    )
    print(f"   best arch FLOPs = {estimate_flops(best_arch, d, t, t1, t2):.3e}", flush=True)

    print("[6/6] Retrain selected arch (1 epoch) and evaluate + mimic attack", flush=True)
    final_model = retrain_architecture(
        arch=best_arch,
        train_loader=train_loader,
        val_loader=val_loader,
        num_epochs=1,
        lr=1e-3,
        d=d,
        t=t,
        t1=t1,
        t2=t2,
        device=device,
    )
    metrics = evaluate_model(final_model, test_loader, device)
    print(f"   eval metrics: {metrics}", flush=True)

    legit_test = test_x[test_y == 1]
    if legit_test.shape[0] >= 4:
        mimic = run_mimic_attack(
            model=final_model,
            legitimate_test_x=legit_test,
            max_noise_std=0.1,
            seed=seed,
            device=device,
            batch_size=4,
        )
        print(f"   mimic metrics: {mimic}", flush=True)
    print("\n[OK] All CPU verification phases completed successfully.", flush=True)


if __name__ == "__main__":
    main()
