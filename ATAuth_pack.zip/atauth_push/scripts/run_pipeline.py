from __future__ import annotations

import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import hydra
import numpy as np
import torch
from omegaconf import DictConfig, OmegaConf
from torch.utils.data import DataLoader

from src.data import (
    BaseSensorDataset,
    build_authentication_pairs,
    build_dataset,
)
from src.evaluation import run_mimic_attack
from src.models.atauth import ATAuthSupernet
from src.nas import regularized_evolution, train_supernet
from src.training import evaluate_model, retrain_architecture
from src.utils import setup_logger, set_global_seed


def _select_users(user_streams: dict[int, np.ndarray], legitimate_user: int, num_unseen: int, seed: int):
    rng = np.random.default_rng(seed)
    all_users = sorted(user_streams.keys())
    if legitimate_user not in all_users:
        legitimate_user = all_users[0]
    others = [u for u in all_users if u != legitimate_user]
    rng.shuffle(others)
    impostor_test = others[:num_unseen]
    impostor_train = others[num_unseen:]
    if len(impostor_train) == 0:
        impostor_train = impostor_test[: max(1, len(impostor_test) // 2)]
    return legitimate_user, impostor_train, impostor_test


@hydra.main(version_base=None, config_path="../configs", config_name="config")
def main(cfg: DictConfig) -> None:
    set_global_seed(cfg.seed)
    logger = setup_logger(cfg.experiment_name, cfg.log_dir)
    logger.info("Configuration:\n" + OmegaConf.to_yaml(cfg))

    device = torch.device(cfg.train.device if torch.cuda.is_available() and cfg.train.device == "cuda" else "cpu")
    logger.info(f"Device: {device}")

    dataset = build_dataset(cfg.dataset.name, cfg.dataset.root)
    user_streams = dataset.load_user_streams()
    sensor_channels = next(iter(user_streams.values())).shape[1]
    logger.info(f"Loaded {len(user_streams)} users, sensor channels = {sensor_channels}")

    legit, imp_train, imp_test = _select_users(user_streams, cfg.legitimate_user, cfg.num_unseen_users, cfg.seed)
    logger.info(f"Legitimate user: {legit}, |impostor_train|={len(imp_train)}, |impostor_test|={len(imp_test)}")

    train_x, train_y, test_x, test_y = build_authentication_pairs(
        user_streams=user_streams,
        legitimate_user=legit,
        train_ratio=cfg.train_ratio,
        num_train_windows=cfg.num_train_windows,
        num_test_windows=cfg.num_test_windows,
        window_length=cfg.window_length,
        impostor_train_users=imp_train,
        impostor_test_users=imp_test,
        pos_neg_ratio_train=tuple(cfg.pos_neg_ratio_train),
        pos_neg_ratio_test=tuple(cfg.pos_neg_ratio_test),
        seed=cfg.seed,
    )

    val_split = max(1, train_x.shape[0] // 10)
    val_x = train_x[:val_split]
    val_y = train_y[:val_split]
    train_x = train_x[val_split:]
    train_y = train_y[val_split:]

    train_loader = DataLoader(BaseSensorDataset(train_x, train_y), batch_size=cfg.batch_size, shuffle=True, num_workers=cfg.train.num_workers)
    val_loader = DataLoader(BaseSensorDataset(val_x, val_y), batch_size=cfg.batch_size, shuffle=False, num_workers=cfg.train.num_workers)
    test_loader = DataLoader(BaseSensorDataset(test_x, test_y), batch_size=cfg.batch_size, shuffle=False, num_workers=cfg.train.num_workers)

    supernet = ATAuthSupernet(
        num_layers=cfg.search.num_layers,
        d=sensor_channels,
        t=cfg.window_length,
        t1=cfg.t1,
        t2=cfg.t2,
        fm_k=cfg.search.fm_k,
        num_classes=2,
    )
    logger.info("Phase 1: supernet training")
    train_supernet(
        supernet=supernet,
        train_loader=train_loader,
        val_loader=val_loader,
        num_epochs=cfg.search.supernet_epochs,
        lr=cfg.search.lr,
        num_layers=cfg.search.num_layers,
        num_cnn_stages=cfg.search.num_cnn_stages,
        device=device,
        seed=cfg.seed,
        log_fn=logger.info,
    )
    os.makedirs(cfg.checkpoint_dir, exist_ok=True)
    torch.save(supernet.state_dict(), os.path.join(cfg.checkpoint_dir, f"{cfg.experiment_name}_supernet.pt"))

    logger.info("Phase 2: regularized evolution")
    best_arch = regularized_evolution(
        supernet=supernet,
        val_loader=val_loader,
        num_layers=cfg.search.num_layers,
        num_cnn_stages=cfg.search.num_cnn_stages,
        d=sensor_channels,
        t=cfg.window_length,
        t1=cfg.t1,
        t2=cfg.t2,
        population_size=cfg.search.population_size,
        tournament_size=cfg.search.tournament_size,
        num_cycles=cfg.search.num_cycles,
        flops_budget=cfg.search.flops_budget,
        latency_budget=cfg.search.latency_budget,
        device=device,
        seed=cfg.seed + 1,
        log_fn=logger.info,
    )

    logger.info("Phase 3: retraining selected architecture")
    model = retrain_architecture(
        arch=best_arch,
        train_loader=train_loader,
        val_loader=val_loader,
        num_epochs=cfg.search.retrain_epochs,
        lr=cfg.search.lr,
        d=sensor_channels,
        t=cfg.window_length,
        t1=cfg.t1,
        t2=cfg.t2,
        device=device,
        log_fn=logger.info,
    )
    torch.save(model.state_dict(), os.path.join(cfg.checkpoint_dir, f"{cfg.experiment_name}_final.pt"))

    logger.info("Phase 4: evaluation on held-out test set")
    metrics = evaluate_model(model, test_loader, device)
    logger.info(f"[test] {metrics}")

    logger.info("Phase 5: mimic attack evaluation")
    legit_test_x = test_x[test_y == 1]
    mimic_metrics = run_mimic_attack(
        model=model,
        legitimate_test_x=legit_test_x,
        max_noise_std=cfg.train.mimic_max_noise,
        seed=cfg.train.mimic_seed,
        device=device,
        batch_size=cfg.batch_size,
    )
    logger.info(f"[mimic] {mimic_metrics}")


if __name__ == "__main__":
    main()
