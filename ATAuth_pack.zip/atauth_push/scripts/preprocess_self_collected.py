from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw_dir", required=True)
    parser.add_argument("--out_dir", required=True)
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    for fname in sorted(os.listdir(args.raw_dir)):
        if not (fname.endswith(".csv") or fname.endswith(".txt")):
            continue
        try:
            uid = int(os.path.splitext(fname)[0].split("_")[-1])
        except ValueError:
            continue
        df = pd.read_csv(os.path.join(args.raw_dir, fname))
        cols = [c for c in df.columns if c.lower() in {"ax", "ay", "az", "gx", "gy", "gz", "mx", "my", "mz"}]
        if len(cols) != 9:
            cols = list(df.columns[:9])
        arr = df[cols].to_numpy(dtype=np.float32)
        np.save(os.path.join(args.out_dir, f"user_{uid}.npy"), arr)
        print(f"saved user {uid}: shape={arr.shape}")


if __name__ == "__main__":
    main()
