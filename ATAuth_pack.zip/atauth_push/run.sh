#!/usr/bin/env bash
set -euo pipefail

DATASET="${DATASET:-ours}"
EXP_NAME="${EXP_NAME:-atauth_${DATASET}_$(date +%Y%m%d_%H%M%S)}"
LEGIT_USER="${LEGIT_USER:-1}"
NUM_UNSEEN="${NUM_UNSEEN:-70}"

python scripts/run_pipeline.py \
  dataset=${DATASET} \
  experiment_name=${EXP_NAME} \
  legitimate_user=${LEGIT_USER} \
  num_unseen_users=${NUM_UNSEEN} \
  "$@"
